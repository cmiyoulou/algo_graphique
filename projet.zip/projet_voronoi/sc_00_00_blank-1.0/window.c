#include <GL4D/gl4dp.h>
#include <GL4D/gl4duw_SDL2.h>
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <cv.h>
#include <highgui.h>


#define DEBUG

static void dessin(void);
static inline void hline(int x0, int x1, int y, GLuint color);
static int fcircle(int x0, int y0, int r, GLuint color);
static void voronoiInitialisation(int n);
static int voronoiGrowing(void);
static void voronoiMoving(void);
static void auRevoir(void);

typedef struct site {
    float x, y;
    float vx, vy;
    GLuint color;
    int growing;
} Site;

static Site * cellules = NULL;
static int nb_sites, radius, libre = 0x0;

//SDL_Surface * image = NULL;
CvCapture *capture = NULL;



int main(int argc, char ** argv){
	//SDL_Surface * src = SDL_LoadBMP("montagne.bmp");

	CvCapture *capture = cvCaptureFromFile(
    "foret.mp4");
    
     if(!capture)
    {
        printf("Erreur d'initialisation !\n");
        exit(1);
    }
    
    cvNamedWindow("Wanscam", CV_WINDOW_AUTOSIZE);
    
    while(1)
    {    
        #ifdef DEBUG
        double t1 = (double)cvGetTickCount();
        #endif
        
        IplImage *img = cvQueryFrame(capture);
        if(img == NULL)
        {
            printf("Erreur de lecture !\n");
            exit(1);
        }
        
        #ifdef DEBUG
        printf("%dx%d pixels (%d canaux couleurs)\n", img->width, img->height, img->nChannels); 
        double t2 = (double)cvGetTickCount();
        printf("time: %gms  fps: %.2g\n", 
               (t2-t1)/(cvGetTickFrequency()*1000.), 1000./((t2-t1)/(cvGetTickFrequency()*1000.)));
        #endif    

        cvShowImage("Wanscam", img);

        // Si on veut sauvegarder l'image
        //cvSaveImage("foo.jpg", img);

        //cvReleaseImage(&img);

        // Appuyez sur une touche pour sortir
        if(cvWaitKey(0) >= 0) break;
    }   
    
    cvReleaseCapture(&capture);

    return 0; 

        
    
    
    
	/*if(src == NULL){
		fprintf(stderr, "Impossible de charger monImage.bmp\n");
		return 2;
	}*/
	
	//image = SDL_CreateRGBSurface(0, src->w, src->h, 32, R_MASK, G_MASK, B_MASK, A_MASK);  
	
	//SDL_BlitSurface(src, NULL, image, NULL);
	
	//SDL_FreeSurface(src);

	/*if(!gl4duwCreateWindow(argc, argv, 
	"GL4Dummies' Hello World",
	10, 10, image->w, image->h,
	GL4DW_SHOWN)){
		return 1;
}
  atexit(auRevoir);

  gl4dpInitScreen();

  gl4duwDisplayFunc(dessin);
  

  gl4duwMainLoop();
  return 0;*/
}

void dessin(void){
	if(!voronoiGrowing()){
		//gl4dpUpdateScreen(NULL);
		voronoiInitialisation(30000);
		voronoiMoving();
		gl4dpUpdateScreen(NULL);
	}

	/*voronoiInitialisation(30000);
	while(voronoiGrowing());*/
	
	gl4dpUpdateScreen(NULL);
	//SDL_Delay(100);
}

static inline void hline(int x0, int x1, int y, GLuint color){
	int w = gl4dpGetWidth(), h = gl4dpGetHeight();
	
	if(y < 0 || y >= h){
		return;
	}
	
	int xg, xd;
	
	if(x0 < x1){
		xg = x0 < 0 ? 0 : x0;
		xd = x1 >= w ? w - 1 : x1;
	} 
	else{
		xg = x1 < 0 ? 0 : x1;
		xd = x0 >= w ? w - 1 : x0;
	}
	
	if(xg >= w || xd < 0){
		return;
	}

	GLuint * p = gl4dpGetPixels();
	
	for(int x = xg, yw = y * w; x <= xd; x++){
		if (p[yw + x] != 0){
			continue;
		}
		
		p[yw + x] = color;
	}
}

int fcircle(int x0, int y0, int r, GLuint color){
	int maxx = ceil(r / sqrt(2.0f)) + 1, r2 = r * r;
	
	for(int x = 0, y; x < maxx; ++x){
		y = ceil(sqrt( r2 - x * x));
		hline((-x + x0), ( x + x0), ( y + y0), color);
		hline((-y + x0), ( y + x0), ( x + y0), color);
		hline((-x + x0), ( x + x0), (-y + y0), color);
		hline((-y + x0), ( y + x0), (-x + y0), color);
	}

	gl4dpScreenHasChanged();
	return 1;
}

void voronoiInitialisation(int n){
	if (cellules) {
		auRevoir();
	}
	else {
		atexit(auRevoir);
	}
	nb_sites = n;
	radius = 1;
	cellules = malloc(sizeof(*cellules) * nb_sites);
	assert(cellules);
	gl4dpClearScreenWith(libre);
	
	for (int i = 0; i < nb_sites; i++){
		cellules[i].x = rand() % gl4dpGetWidth();
		cellules[i].y = rand() % gl4dpGetHeight();
		cellules[i].vx = 10.0 * (2.0 * (rand() / (RAND_MAX + 1.0)) - 1.0);
		cellules[i].vy = 10.0 * (2.0 * (rand() / (RAND_MAX + 1.0)) - 1.0);
		
		/*GLubyte r = rand()&0xFF, g = rand()&0xFF, b = rand()&0xFF;
		cellules[i].color = RGB(r,g,b);*/
		
		cellules[i].color = ((GLuint *)image->pixels)[(gl4dpGetHeight() - ((int)cellules[i].y) - 1) * gl4dpGetWidth() + ((int)cellules[i].x)];

		cellules[i].growing = 1;
	}
}

int voronoiGrowing(void){
	int growing = 0;

	for (int i = 0; i < nb_sites; i++){
		if(!cellules[i].growing){ 
			continue;
		}
		
		if (fcircle(cellules[i].x, cellules[i].y, radius, cellules[i].color)){
			growing = 1;
		}
		
		else{
			cellules[i].growing = 0;
		}
	}
	
	if(growing) {
		gl4dpScreenHasChanged();
	}
	//gl4dpUpdateScreen(NULL);
	++radius;
	return growing;
}

void voronoiMoving(void){
	gl4dpClearScreenWith(libre);
	for(int i = 0; i < nb_sites; ++i) {
		cellules[i].x += cellules[i].vx;
		while(cellules[i].x < 0.0f) {
			cellules[i].x += gl4dpGetWidth();
		}
		while(cellules[i].x >= gl4dpGetWidth()) {
			cellules[i].x -= gl4dpGetWidth();	
		}
		cellules[i].y +=cellules[i].vy;
		while(cellules[i].y < 0.0f) {
			cellules[i].y += gl4dpGetHeight();
		}
		while(cellules[i].y >= gl4dpGetHeight()) {
			cellules[i].y -= gl4dpGetHeight();	
		}
		cellules[i].color = ((GLuint *) image->pixels)[(gl4dpGetHeight() - ((int)cellules[i].y) - 1) * gl4dpGetWidth() + ((int)cellules[i].x)];
		cellules[i].growing = 1;
	}
	radius = 0;
}

void auRevoir(void){
	if(image){
		SDL_FreeSurface(image);
		image = NULL;
		printf("C'est bon \n \n");
	}
}
















